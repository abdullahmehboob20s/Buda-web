OTF and TTF: K�nigsberg (Regular, Bold, Semi Bold, Light, and Ultra Light)
Dennis Ludlow 2016 all rights reserved
by Sharkshock 
dennis@sharkshock.net

K�nigsberg is a fun and clean display font with 5 different weights for many different uses. It's softend style captures the feel of classic doughnut shops and children's books of the 70's. This rounded sans serif features matching uppercase and lowercase characters with the exception of Light and
Ultra Light. Basic latin, extended latin, diacritics, punctuation, and kerning are available. Use the Bold version for a kid friendly poster or Ultra Light for an elegant logo. Please check included glyph maps for a look at all the characters.

A demo of the regular version is included for personal use. Full version plus all 5 weights can be purchased for $15 or by purchasing a commercial license. 

Please note the $15 purchase is for PERSONAL use only and does NOT initiate a business contract.

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license agreement. You can also visit www.sharkshock.net/license for more info and terms. I also design custom 
fonts for companies, logos, and many other things. If you'd like to leave me a PayPal donation you can use my email address above. Your generosity will be most appreciated! 

Thank you for your support!

visit www.sharkshock.net for more and take a bite out of BORING design!

tags: retro, display, font, typeface, publishing, logo, title, book, cover, magazine, company, style, brand, branding, kid, sans, san serif, TV, cartoon, cartoons, saturday, Disney, Mickey, character, like, poster, headline, Porky, animation, children, children's, kids, playful, wacky, fun, funny, comedy




